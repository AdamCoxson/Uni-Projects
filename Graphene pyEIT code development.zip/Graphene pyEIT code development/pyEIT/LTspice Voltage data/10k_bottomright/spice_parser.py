import numpy as np


#file_name = "/Users/frederik/Software Development/MPhys/Python/Spice/Simulations/10Meg/0.txt"

def read_file_to_numpy(file_name):
  f = open(file_name, "r")
  v_array = []
  i = 0
  for x in f:
    x = x.split('=')
    x = x[1].split(' ')
    v = x[0]
    v = float(v)
    v_array.append(v)
  v_array = np.array(v_array)
  return v_array

def write_file_from_numpy(file_name, array):
  np.savetxt(file_name, array, delimiter=',')


def all_files():
  for i in range(0, 32):
    in_name = "/Users/frederik/Software Development/MPhys/Python/Spice/Simulations/10k_bottomright/corrected_order/" + str(i) + ".txt"
    out_name = "/Users/frederik/Software Development/MPhys/Python/Spice/Simulations/10k_bottomright/corrected_order/csv/" + str(i) + ".csv"
    write_file_from_numpy(out_name, read_file_to_numpy(in_name))

all_files()