This modular folder

The previous MPhys pair modifed the source files of the vanilla pyEIT package. 

fem_for_given_meas and fem_forallmeas were added so won't conflict.
fem was modifed.

To discern between the two

fem and fem_original means the package is using ivos modified fem file.
if you want to swithc back to the original, rename fem to fem_ivo and then change
fem_original back to fem