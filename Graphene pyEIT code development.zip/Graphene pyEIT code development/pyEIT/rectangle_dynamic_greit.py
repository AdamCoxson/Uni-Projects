# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 10:16:14 2020
Author: Adam Coxson, Master of Physics Undergrad, The University of Manchester
Project: 
Module: 
Dependancies: 
"""

from __future__ import division, absolute_import, print_function

import numpy as np
import matplotlib.pyplot as plt

import mesh as mesh
from mesh.shape import rectangle
from eit.fem import Forward
from eit.utils import eit_scan_lines
import eit.greit as greit

from datetime import datetime

def electrode_posns(n_el, n_sides=4):
    """
    Calculate fixed electrode positions for a regular shape.
    
    Parameters
    ----------
    n_el: (int) Total number of electrodes
    n:    (int) Number of sides, default 4 for square sample
    
    Returns
    -------
    electrode_positions (array (n_el,2)): An array containing x,y coordinates
        for fixed electrode positions. CW along perimeter from 9 o'clock pos.  

    Notes
    -----
    This produces and array containing the (x,y) values for regularly spaced 
    fixed electrode positions for a regular 2D shape. It ensures the first 
    electrode is at the 9 o'clock point on the perimeter of the sample and 
    continues clockwise for subsequent electrode numbers.
   
    WARNING
    -------
    Check the electrodes do follow the samples perimeter in a 
    clockwise manner. 
    TO DO: Account for an even/odd no. of electrodes per side. Use an if statement.
    """
    # Getting equally spaced co-ords
    posns = (np.arange(1,(n_el/n_sides+1)) * 2/(n_el/n_sides+1)) - 1 
    ones = np.ones(np.size(posns))
    top = np.array((posns, ones)).T # top row of electrode positions
    bottom = np.array((-posns, -ones)).T # +/- signs ensure CW allocation
    left = np.array((-ones, posns)).T
    right = np.array((ones, -posns)).T
    args = (left,top,right,bottom) # ordered CW from centre of left side.
    electrode_positions = np.concatenate(args)
    # Below is hardcoded for 8 electrodes per side, need to account for even and odd n_el shifting
    electrode_positions = np.roll(electrode_positions, -4, axis=0) # Shift to 9 o'clock position
    return electrode_positions

def read_data(n_files=32):
    path = 'LTspice Voltage data\\uniform_r_grid\\' # path is myCWD\\LTspice ... 
    voltages = []
    for i in range(0, n_files):
        filename = path+str(i)+'.csv'
        voltages = np.concatenate((voltages,np.genfromtxt(filename,delimiter=',')),axis=None)
    return voltages
 
n_electrodes = 32  # Square mesh with 8 electrodes per side
el_posns = electrode_posns(n_electrodes)
new_voltages = read_data(n_electrodes)
init_time_A = datetime.now()
""" 0. construct mesh """

# def _fd(pts):
#     rect = shape.rectangle(pts, p1=[-1, -1], p2=[1, 1])
#     circle = shape.circle(pts, r=0.5)
#     return shape.dist_diff(rect, circle)
def _fd(pts):
    rect = rectangle(pts, p1=[-1, -1], p2=[1, 1])
    return rect
mesh_obj, el_pos, p_fix = mesh.create(n_el=n_electrodes, fd=_fd, fh=None, p_fix=el_posns, bbox=None, h0=0.1)

# extract node, element, alpha
pts = mesh_obj['node']
tri = mesh_obj['element']

""" 1. problem setup """
# this step is not needed, actually
# mesh_0 = mesh.set_perm(mesh_obj, background=1.0)

# test function for altering the 'permittivity' in mesh
anomaly = [{'x': 0.4,  'y': 0,    'd': 0.4, 'perm': 10},
           {'x': -0.4, 'y': 0,    'd': 0.2, 'perm': 0.1},
           {'x': 0,    'y': 0.5,  'd': 0.1, 'perm': 10},
           {'x': 0,    'y': -0.5, 'd': 0.1, 'perm': 0.1}]
mesh_new = mesh.set_perm(mesh_obj, anomaly=anomaly, background=1.0)
delta_perm = np.real(mesh_new['perm'] - mesh_obj['perm'])

#show alpha
fig, ax = plt.subplots()
im = ax.tripcolor(pts[:, 0], pts[:, 1], tri, delta_perm,
                  shading='flat', cmap=plt.cm.viridis)
fig.colorbar(im)
ax.axis('equal')
ax.set_xlim([-1.2, 1.2])
ax.set_ylim([-1.2, 1.2])
ax.set_title(r'$\Delta$ Conductivity')
#fig.set_size_inches(6, 4)

""" 2. FEM forward simulations """
# setup EIT scan conditions
el_dist, step = 1, 1
ex_mat = eit_scan_lines(n_electrodes, el_dist)

# calculate simulated data
fwd = Forward(mesh_obj, el_pos)
#fwd = Forward(mesh_obj, el_pos, 16)
f0 = fwd.solve_eit(ex_mat, step=step, perm=mesh_obj['perm'])
print("New Forward Solver f1 activated------------")
#f1 = fwd.solve_eit(ex_mat, step=step, perm=mesh_new['perm'])
init_time_B = datetime.now()

""" 3. Construct using GREIT """
eit = greit.GREIT(mesh_obj, el_pos, ex_mat=ex_mat, step=step, parser='std')
eit.setup(p=0.50, lamb=0.001)
#ds = eit.solve(f1.v, f0.v)
ds = eit.solve(-new_voltages, f0.v)
x, y, ds = eit.mask_value(ds, mask_value=np.NAN)

fin_time_B = datetime.now()

# plotting the final GREIT images

fig, ax = plt.subplots()
cmap = plt.cm.viridis
#cmap = plt.cm.gray
im = ax.imshow(np.real(ds), interpolation='none', cmap=cmap,vmin=0,vmax=1)
fig.colorbar(im)
ax.set_title('Resistor grid GREIT')
ax.axis('equal')
# fig.set_size_inches(6, 4)
# fig.savefig('../figs/demo_greit.png', dpi=96)
plt.show()

fig, ax = plt.subplots()
im = ax.imshow(np.real(ds), interpolation='none', cmap=cmap)
fig.colorbar(im)
ax.set_title('Resistor grid GREIT (scaled min to max)')
ax.axis('equal')
# fig.set_size_inches(6, 4)
# fig.savefig('../figs/demo_greit.png', dpi=96)
plt.show()

fin_time_A = datetime.now()
print("Total script execution time:", fin_time_A - init_time_A)
print("Inverse problem, GREIT execution time:", fin_time_B - init_time_B)
#plt.close('all')
