// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// battle.h - 40 lines as of 10/05/2020, battle.cpp has 244 lines.
// This is responsible for the dice class and resolving unit battles using 3 standalone functions.
// The dice class is only used within the unit_battle, retreat and castle_siege functions.
// The 3 functions are solely called from and output to the unit_move() function in board.cpp
#pragma once
#ifndef battle_h
#define battle_h
#include<string>
#include<vector>
#include<iostream>
#include<algorithm>
#include"units_and_upgrades.h"
#include"input_validation.h" // only uses int_list_input() and two_char_input()
class dice
{
private:
	int faces{ 6 };
	int Num_of_dice{ 1 };
public:
	std::vector<int> scores{};
	dice() = default;
	dice(const int faces_in, const int Num_dice_in);
	~dice() {}
	std::vector<int> roll_dice();
	std::vector<int> sort_scores() const;
	int get_first_score() const;
	void print_scores() const;
	void reset_scores();
	void reset_dice_params(const int faces_in, const int Num_of_dice_in);
	void reset_all(const int faces_in, const int Num_of_dice_in);
};
std::string retreat(int &retreater_strength);
std::string unit_battle(std::shared_ptr<unit> attacker,std::shared_ptr<unit> defender,std::pair<bool, bool> empty_castle);
std::string castle_siege(std::shared_ptr<unit> attacker,int &castle_strength);
#endif