// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// input_validation.cpp - see input_validation.h for description. 253 lines as of 10/05/2020.
#include "input_validation.h"
int int_list_input(const int start_int, const int last_int)
// This function takes in a starting value and final value from a selection list printed to the user
// somewhere else in the propram (see upgrade_phase in main.cpp for an example).
// The list choices are in the form: (N_s = start, N_l = last) [N_s],[N_s+1],[N_s+2],...,[N_l]
// The user can't continue until one of the correct N integer values are inputted.
{
	std::string input;
	int choice;
	while (true) {
		try {
			std::getline(std::cin, input);
			std::for_each(input.begin(), input.end(), [](char& it) {
				if (std::isdigit(it) == false) { throw std::invalid_argument("Input must be an integer,"); }
				});
			choice = stoi(input);
			if (choice > start_int - 1 && choice < last_int + 1) {
				return choice;
			} else {
				throw std::invalid_argument("Input must be a valid integer choice,");
			}
		} catch (std::invalid_argument &exp) {
			std::cerr << " Exception occured: " << exp.what() << " try again: ";
		} catch (...) { 
			std::cerr << " Some unknown exception occured.\n";
			exit(1);
		}
	}
}
std::string two_char_input(std::string A, std::string B) 
// This function takes in two strings or characters which where presented as input choices to
// the user somewhere else in the propram (see deployment_phase in main.cpp for an example).
// The user can't continue until one of the correct strings are inputted.
// for 'enter to continue' inputs, ensure A arg == ""
{
	std::string input;
	while (true) {
		std::getline(std::cin, input);
		if (input == A) { return A; }
		else if (input == B) { return B; }
		else {
			if (A == ""){
				std::cout << " Invalid input, must press the enter key or input " << B << ", try again:";
			} else {
				std::cout << " Invalid input, must be " << A << " or " << B << ", try again:";
			}
		}
	}
}
void rules_reader(std::string filename)
{ // Takes in a text file and writes outputs the lines to os, used for game_rules.txt.
	std::ifstream file(filename);
	std::string line;
	if (file.is_open()) {        
		std::cout << " Opened " << filename << " successfully" << std::endl;
		while (!file.eof()) {
			std::getline(file, line, '\n');
			std::cout << " " << line << "\n"; 
		}
	} else {
		std::cout << " Unable to open " << filename << " for reading\n";
		exit(1);
	}
}
void check_files_valid(std::vector<std::string> file_list) 
{ // This attempts to open the 4 pre-defined configs files to check if they are present and valid.
	std::string current_file{ "" };
	try {
		for_each(file_list.begin(), file_list.end(), [&current_file](std::string file) {
			current_file = file;
			std::ifstream file_check(file);
			if(file_check.good()){
				file_check.close();
			} else {
				throw std::runtime_error("runtime_error, "+current_file+" file could not open.");
			}
		});
	} catch (std::runtime_error &exp){
		std::cout << " Exception occured: " << exp.what()<<"\n";
		std::cout << " Ensure cfg_base_game.csv, cfg_quick_game.csv, "
		          << " cfg_debug.csv, and cfg_river_crossing.csv files are all in the source folder.\n";
		exit(1);
	} catch (...) {
		std::cout << " Unknown exception occured: Ensure cfg_base_game.csv,cfg_quick_game.csv,";
		std::cout << " cfg_debug.csv, and cfg_river_crossing.csv files are all in the source folder.\n";
		exit(1);
	}
}
std::vector<std::vector<std::string>> config_reader(std::vector<std::shared_ptr<unit>>& units)
// This function takes in the empty unit storage vector by reference so it can initialise the units.
// Using preset csv file configurations, the user can choose a map config to load.
// This reads the chosen file in and uses the data to initialise the units into the vector.
// Returns a 2D vector of strings that stores map data to be passed into the board constructor in main.cpp. 
{
	std::vector<std::string> file_list{ "cfg_base_game.csv","cfg_quick_game.csv","cfg_river_crossing.csv","cfg_debug.csv" };
	if (std::ifstream("cfg_last_save.csv").good()) {
		file_list.emplace_back("cfg_last_save.csv"); // If save file is present, add to user file choice options
	}
	check_files_valid(file_list);
	std::vector<std::vector<std::string>> config;
	std::string filename{};
	std::string type{}; // string variables explicitly stated for clarity incase of error
	std::string team{};
	std::string x{};
	std::string y{};
	std::string str{};
	std::string upgrade{};
	std::cout << " Choose a file config to start.\n";
	for (size_t i{};i<file_list.size();i++){
		std::cout << " ["<< i + 1<< "] "<< file_list[i]<<"\n";
	}
	std::cout << " Choose an option (input number identifier): ";
	filename = file_list[int_list_input(1, file_list.size())-1];
	std::ifstream file(filename);
	if (file.is_open()) {         // Check to see the file is open
		try {
			std::cout << " Opened " << filename << " successfully" << std::endl;
			file.ignore(80, '\n'); // skips header lines in csv
			std::getline(file, type, ','); // rows - reusing temp variables for initial row
			std::getline(file, team, ','); // cols
			std::getline(file, y, ',');    // blue & red start gold
			std::getline(file, x, '\n');
			config.emplace_back(std::vector<std::string>{type, team, y, x }); // initial board parameters
			file.ignore(80, '\n');
			file.ignore(80, '\n');
			while (true) {
				std::getline(file, type, ',');
				std::getline(file, team, ',');
				std::getline(file, x, ',');
				std::getline(file, y, ',');
				std::getline(file, str);
				if (team == "") {
					team = " ";
				}
				if (type == "units") {
					break;
				} else if (type != "Castle" && type != "Gold" && type != "Obstacle") {
					throw std::invalid_argument(" Tile type strings must be 'Castle', 'Gold', or 'Obstacle'.");
				} else if (team != "Blue" && team != "Red" && team != " ") {
					throw std::invalid_argument(" Tile team strings must be blank, 'Red', or 'Blue'.");
				} else if (stoi(x) > stoi(config[0][1]) - 1 || stoi(x) < 0 || stoi(y) > stoi(config[0][0]) - 1 || stoi(y) < 0) {
					throw std::out_of_range(" x and y values must be within grid boundaries");
				} else if ((4 < stoi(str) || stoi(str) < -1) && type == "Castle") {
					throw std::out_of_range(" Castle strength values must be 0-4.");
				} else{}
				config.emplace_back(std::vector<std::string>{type, team, x, y, str}); // config variable to be used in board constructor
			}
			while (!file.eof()) {
				std::getline(file, type, ',');
				std::getline(file, team, ',');
				std::getline(file, x, ',');
				std::getline(file, y, ',');
				std::getline(file, str, ',');
				std::getline(file, upgrade);
				if (type == "") {
					break;
				} else if (team != "Blue" && team != "Red") {
					throw std::invalid_argument(" Unit team strings must be 'Red', or 'Blue'.");
				} else if (stoi(x) > stoi(config[0][1]) - 1 || stoi(x) < 0 || stoi(y) > stoi(config[0][0]) - 1 || stoi(y) < 0) {
					throw std::out_of_range(" x and y values must be within grid boundaries");
				} else if (9 < stoi(str) || stoi(str) < 1 && type == "Army") {
					throw std::out_of_range(" Army strength values must be 1-9.");
				} else {}
				if (type == "Scout") { // initialisting units and constructing directly into unit storage vector
					units.emplace_back(std::make_shared<scout>(team, stoi(x), stoi(y), upgrade));
				} else if (type == "Army") {
					units.emplace_back(std::make_shared<army>(team, stoi(str), stoi(x), stoi(y), upgrade));
				} else {
					throw std::invalid_argument(" Unit type strings must be 'Army' or 'Scout'.");
				}
			}
		} catch (std::invalid_argument& exp) { // tries and catches incase of specific error in config file
			std::cout << " Exception: Invalid argument. Check for errors in config file.\n";
			std::cout << exp.what();
			exit(1);
		} catch (std::out_of_range &exp) {
			std::cout << " Exception: Vector out of range. Check for errors in config file.\n";
			std::cout << exp.what();
			exit(1);
		} catch (std::bad_alloc) {
			std::cout << " Exception: bad_alloc. Out of memory, check for errors in config file.\n";
			exit(1);
		} catch (std::length_error) {
			std::cout << " Exception: length_error. Some string is too long, check for errors in config file.\n";
			exit(1);
		} catch (...) {
			std::cout << "Exception: Some unknown exception occured\n";
			exit(1);
		}
		file.close();
		std::cout << " " << filename << " finished reading." << std::endl;
	} else {
		std::cout << " Unable to open " << filename << " for reading\n";
		exit(1);
	}
	return config;
}
void config_save_game(std::vector<std::shared_ptr<unit>>& units, std::vector<std::vector<std::unique_ptr<board_tile>>>& map,
	std::vector<std::string> config_initial)
	// This function takes in the current map from the board, the units and cols,rows, blue gold and red gold.
	// It writes the data to a csv file called cfg_last_save.csv in the correct format for game load config file.
	// Currently only supports 1 save file and overwrites the file if it is already there.
{
	std::string rows = config_initial[0];
	std::string cols = config_initial[1];
	std::string blue_gold = config_initial[2];
	std::string red_gold = config_initial[3];
	std::ofstream save_file("cfg_last_save.csv");
	std::vector<std::string> line(6);
	save_file << "rows_y,cols_x,start_gold_blue,start_gold_red"<<"\n"; // Header
	save_file << rows << "," << cols << "," << blue_gold << "," << red_gold << "\n";
	save_file << "type,team,x,y,strength,upgrades"<<"\n";// Headers
	save_file << "tile"<<"\n";
	for (int i{}; i < stoi(rows); i++) { // writing board_tiles
		for (int j{}; j < stoi(cols); j++) {
			if (map[i][j]->get_type() == " ") { 
				continue; // no need to write empty slot details
			} 
			line[0] = map[i][j]->get_type();
			if (map[i][j]->get_team() == " ") {
				line[1] = "";
			} else {
				line[1] = map[i][j]->get_team();
			}
			line[2] = std::to_string(map[i][j]->getX());
			line[3] = std::to_string(map[i][j]->getY());
			line[4] = std::to_string(map[i][j]->get_strength());
			save_file << line[0] << "," << line[1] << "," << line[2] << "," << line[3] << "," << line[4] << "\n";
		}
	}
	save_file << "units,,,,,"<<"\n"; // Lambda to write out unit data
	for_each(units.begin(), units.end(), [&line, &save_file](std::shared_ptr<unit> unit) {
		line[0] = unit->get_type();
		line[1] = unit->get_team();
		line[2] = std::to_string(unit->getX());
		line[3] = std::to_string(unit->getY());
		line[4] = std::to_string(unit->get_strength());
		if (unit->get_upgrade_type() == "[a] Veteran Leaders") { line[5] = "attack"; }
		else if (unit->get_upgrade_type() == "[d] Shields and Armour") { line[5] = "defense"; }
		else if (unit->get_upgrade_type() == "[s] Siege Tactics") { line[5] = "siege"; }
		else if (unit->get_upgrade_type() == "[m] Mounted Army") { line[5] = "move"; }
		else { line[5] = "none"; }
		save_file << line[0] << "," << line[1] << "," << line[2] << "," << line[3] << "," << line[4] <<
			"," << line[5] << "\n";
	});
	save_file.close();
}