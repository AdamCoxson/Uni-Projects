// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4 (no warnings on compilation for me)
// ------------------------------------------------------------
// Main.cpp - 222 lines as of 11/05/2020
// This standalone cpp deals with the config file loading and the turn system. (for custom maps see custom config instructions word doc)
// The turn System is in two phases. Movement phase, and reforcement phase (deployment and upgrades)
// File line break down - note these numbers include all commented lines so are overestimates
// main.cpp                                  =  222
// board.h              + .cpp  =  57 + 512  =  569 
// board_tile.h         + .cpp  =  83 + 63   =  146
// units_and_upgrades.h + .cpp  = 135 + 167  =  302
// battle.h             + .cpp  =  40 + 244  =  284
// input_validation.h   + .cpp  =  30 + 253  =  283
// In total:                    = 345 + 1461 = 1806 lines ~ 1600 excluding comment headers.
#include<iostream>
#include<string>
#include<memory>
#include<time.h>       // time 
#include<algorithm>    // For std::remove_if and std::for_each
#include"board.h"
#include"units_and_upgrades.h"
#include"input_validation.h"

void deployment_phase(const std::string team, std::vector<std::shared_ptr<unit>> &units, board &board)
// This function takes in the current team, the units vector and current board to enable deployment of new
// units to the board or 'muster' to increase every armies strength by 1, up to a maximum of 9. The user
// has a choice between the two unless the max army limit has been reached, (2 + no. of castles), or there
// are no empty castles to deploy to. If the user does not deploy, they muster instead.
{
	std::string deployment_choice;
	const int base_army_count{ 2 };
	int muster_points{ units[0]->army_count(team) };
	if (muster_points < 2) { muster_points = 2; }
	std::cout << "\n " << team << " team reinforcement phase.";
	if (muster_points < base_army_count + board.get_castles(team) // input from user or check max army limit
		&& board.check_for_empty_castle(team) == true) {
		std::cout <<"\n [d] Deploy new army with strength " << muster_points <<  " to an empty castle.\n"
			      <<  " [m] Muster to increase all armies' strengths by 1.\n [d / m]: ";
		deployment_choice = two_char_input("d", "m");
	} else {
		std::cout << "\n Maximum " << team << " army count reached, or no empty castles to deploy at.\n";
		deployment_choice = "m";
	}
	if (deployment_choice == "d") {
		std::cout << "\n Deploying new army.\n"; 
		units.emplace_back(std::make_shared<army>(team, muster_points, 0, 0, "none"));
		board.deploy_army(team, units.back()); // Call board fuction to deploy army to a tile
		board.print_board(nullptr);
	} else if (deployment_choice == "m") {
		for (auto unit : units) {
			if (unit->get_team() == team) { unit->add_one_strength(); }
		}
		board.print_board(nullptr);
		std::cout << "\n Mustering, increasing all " << team << " armies' strengths by 1.\n";
	}
}
void upgrade_phase(const std::string team, std::vector<std::shared_ptr<unit>>& units, upgrade_list& upgrades, board& board) 
// This function takes in the current team, unit list, upgrades and the board. Totals up the gold earned by team last round 
// and adds to the gold static integers in board. +1 gold for each castle and +2 for each gold mine. Also checks if player 
// has enough gold left. A selection is presented to enable player to buy upgrades for units or upgrade castles. 
{
	bool end_phase{false};
	int upgrade_choice;
	int unit_choice;
	int j{};
	std::vector<int> unit_indexes(units.size(),0);
	board.total_up_gold(team);
	std::for_each(upgrades.list.begin(),upgrades.list.end(), [&board, &team]( std::shared_ptr<upgrade> upgrade)
			{upgrade->print_info(board.get_gold(team));}); // Printing out the upgrade info
	std::cout << "\n " << team << " team, gold in treasury: " << board.get_gold(team) << "\n";
	while (end_phase == false) {
		if (board.get_gold(team) < upgrades.list[0]->get_minimum_cost()) {
			std::cout << " Ending " << team << "'s upgrade phase. Not enough gold to buy anything.\n";
			break;
		}
		std::cout << " [0] End upgrade phase" << std::endl;
		std::cout << " [1] Upgrade castle fortifications" << std::endl;
		j = 0;
		for (size_t i{ }; i < units.size(); i++) { // output team's units in list form for user selection
			if (units[i]->get_team() == team){
				std::cout << " [" << j+2 << "]";
				units[i]->print_unit_info();
				unit_indexes[j] = i;
				j++;
			}
		}
		std::cout << " Choose an option (input number identifier): ";
		unit_choice = int_list_input(0, j+1);
		if (unit_choice == 0) {
			end_phase = true;
		} else if (unit_choice == 1) {
			board.upgrade_castle(team);
			std::cout << "\n";
		} else {
			unit_choice = unit_indexes[unit_choice - 2]; // Redefine choice to account for offset in indices
			std::cout << "\n";
			units[unit_choice]->print_unit_info();
			std::cout << " Available gold: " << board.get_gold(team) << "\n";
			std::cout << " [0] Cancel - back to previous selection.\n";
			std::cout << " [1] Attack:   Veteran Leaders.  Cost: " << upgrades.list[0]->get_cost() << ".\n";
			std::cout << " [2] Defense:  Shields & Armour. Cost: " << upgrades.list[1]->get_cost() << ".\n";
			std::cout << " [3] Siege:    Siege Tactics.    Cost: " << upgrades.list[2]->get_cost() << ".\n";
			std::cout << " [4] Movement: Mounted Army.     Cost: " << upgrades.list[3]->get_cost() << ".\n";
			std::cout << " Choose an option (input number identifier): ";
			while (true) {
				upgrade_choice = int_list_input(0, 4); 
				std::cout << "\n";
				if (upgrade_choice == 0) {
					break;
				} else if (upgrades.list[upgrade_choice - 1]->get_cost() > board.get_gold(team)) {
					std::cout << " You don't have enough gold! Try again: ";
				} else if (upgrades.list[upgrade_choice - 1]->get_type() == units[unit_choice]->get_upgrade_type()) {
					std::cout << " You already have that upgrade! Try again: ";
				} else {
					units[unit_choice]->upgrade(upgrades.list[upgrade_choice - 1]);
					board.spend_gold(team, upgrades.list[upgrade_choice - 1]->get_cost());
					std::cout << " Unit upgraded with " << upgrades.list[upgrade_choice - 1]->get_type() << ".\n";
					break;
				}
			}
		}
	}
	std::cout << "\n " << team << " team, gold in treasury: " << board.get_gold(team) << "\n";
}
int main() 
{
	srand((unsigned int)time(NULL)); // Seeding random number generator for dice class in battle.h and .cpp
	int game_option{};
	std::string next_turn{};
	std::vector<std::string> teams{ "Blue", "Red" };
	std::vector<std::shared_ptr<unit>> units;
	std::vector<std::vector<std::string>> config;
	upgrade_list upgrades;

	rules_reader("game_rules.txt");
	std::cout << "\n Your Armies await you, Commander . . . (Press enter, or input anything start).\n";
	std::getline(std::cin, next_turn);
	config = config_reader(units); 
	board myboard(units, config);
	while (next_turn != "n") {
		std::cout << "\n Movement phase. Use WASD keys, i.e. 'www' means go up 3 squares.\n";
		for (int i{}; i < 2; i++) {
			for (auto current_unit : units) {
				if (current_unit->get_strength() != 0 && current_unit->get_team() == teams[i]) {
					myboard.move_unit(current_unit);
				}
				if (units[0]->unit_count("Blue") == 0) { // Endgame condition checks
					std::cout << "\n All blue units defeated.\n Red has won the game.\n\n";
					next_turn = "n";
					break;
				} else if (units[0]->unit_count("Red") == 0) {
					std::cout << "\n All red units defeated.\n Blue has won the game.\n\n";
					next_turn = "n";
					break;
				} else {}
			}
			if (next_turn == "n") { break; }
		}
		// Find, and remove, any dead units
		units.erase(std::remove_if(units.begin(), units.end(),
			[](std::shared_ptr<unit>& x) -> bool 
			{ 
				return x->get_strength() == 0;  
			}
		),units.end());
		if (next_turn == "n") { break; }
		myboard.print_board(nullptr);
		std::cout << "\n Castles owned: Red = " << myboard.get_castles("Red") << ", Blue = " << myboard.get_castles("Blue") <<"\n";
		if (myboard.get_castles("Red") == 0) {
			std::cout << "\n All red castles captured.\n Blue has won the game.\n"; // Endgame condition check at end of movement phase
			break;
		} else if (myboard.get_castles("Blue") == 0) {
			std::cout << "\n All blue castles captured.\n Red has won the game.\n";
			break;
		} else {
			std::for_each(teams.begin(), teams.end(), [&myboard, &units, &upgrades](std::string& team)
			{
					deployment_phase(team, units, myboard); // reinforcement phase loop for each team, calls funcs defined above main
					upgrade_phase(team, units, upgrades, myboard);
					myboard.print_board(nullptr);
			});
			std::cout << "\n Press enter for the next turn, or enter 'o' for game options: "; // end of turn user options
			next_turn = two_char_input("", "o");
			if (next_turn == "o") {
				std::cout << " [0] Continue to next turn. \n";
				std::cout << " [1] Save game and continue.\n";
				std::cout << " [2] Save game and quit.    \n";
				std::cout << " [3] Quit without saving.   \n";
				std::cout << " [4] Help - print out rules and continue.\n";
				std::cout << " NOTE: Saving will overwrite cfg_last_save.csv, multisaving not implemented yet.";
				std::cout << "\n Choose an option (input number identifier): ";
				game_option = int_list_input(0, 4);
				std::cout << "\n";
				if (game_option == 0) {
					continue;
				} else if (game_option == 1 || game_option == 2) {
					config[0][2] = std::to_string(myboard.get_gold("Blue"));
					config[0][3] = std::to_string(myboard.get_gold("Red"));
					config_save_game(units, myboard.map, config[0]);
					if (game_option == 1) { 
						std::cout << " Saving and continuing game.\n ";
					} else {
						std::cout << " Saving and quitting game.\n ";
						next_turn = "n";
					}
				} else if (game_option == 3) {
					std::cout << " Quitting game.\n ";
					next_turn = "n";
				} else if (game_option == 4) {
					rules_reader("game_rules.txt");
					std::cout << "\n Press enter to continue, or enter 'n' to quit:\n";
					next_turn = two_char_input("","n");
				} else {
					std::cout << " Something with game_option input went wrong.\n";
				}
			}
		}
	}
	return 0;
}