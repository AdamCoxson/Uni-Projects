// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// board_tile.h - 83 lines as of 10/05/2020, board_tile.cpp has 63 lines
// This contains classes for board tiles. 
// board_tile abstract base class -> Derived: empty, obstacle, gold_point, castle.
// Board tiles are objects which are set and stored in a 2D vector of unique pointers of the base
// class called map in the board class. This allows a grid of board tiles to be generated to 
// represent a map. The board tiles have a single shared pointer to units. This allows units to
// be displayed on individual tiles and for other units to interact with them through the map.
#pragma once
#ifndef board_tile_h
#define board_tile_h
#include"units_and_upgrades.h" // Only required for shared unit pointer
#include<string>
class board_tile
{ // Abstract base class, derives to empty, obstacle, gold_point and castle
protected:
	std::string team{ " " }; // initialised for empty space tile
	std::string tile{ " " };
	std::shared_ptr<unit> unit_slot{ nullptr }; // pointer link to tile's unit
	int x{}, y{};
public:
	board_tile() = default;
	~board_tile() {}
	std::string get_team() { return team; }
	std::string get_type() { return tile; }
	std::shared_ptr<unit> get_unit() { return unit_slot; }
	int getX() { return x; }
	int getY() { return y; }
	void setXY(const int x_input, const int y_input);
	void set_team(std::string team_in) { team = team_in; }
	void set_unit(std::shared_ptr<unit> unit_in) { unit_slot = std::move(unit_in); }
	bool check_for_unit() const;
	virtual int get_strength() const = 0; 
	virtual void set_strength(const int new_strength) = 0; // for castle strength upgrade
	virtual void print_tile(const bool moving_unit) const = 0;
};
class empty : public board_tile
{
public:
	empty() = default;
	~empty() {}
	int get_strength() const { return 0; };
	void set_strength(const int new_strength) {}; 
	void print_tile(const bool moving_unit) const;
};
class obstacle : public board_tile
{
public:
	obstacle();
	~obstacle() {}
	int get_strength() const { return 0; };
	void set_strength(const int new_strength) {};
	void print_tile(const bool moving_unit) const;
};
class gold_point : public board_tile
{
protected:
	int strength{};
public:
	gold_point() = default;
	gold_point(std::string team_in, int strength_in);
	~gold_point() {}
	int get_strength() const { return strength; };
	void set_strength(const int new_strength) {};
	void print_tile(const bool moving_unit) const;
};
class castle : public board_tile
{
protected:
	int strength{};
public:
	castle() = default;
	castle(std::string team_in, int strength_in);
	~castle();
	int get_strength() const;
	void set_strength(const int new_strength);
	void print_tile(const bool moving_unit) const;
};
#endif