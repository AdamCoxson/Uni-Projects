// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// input_validation.h - 30 lines as of 10/05/2020, .cpp has 253
// This file only contains functions used for data and input validation.
// The first two functions, int_list_input and two_char_input are for ensuring the
// user inputs correct choices, e.g. in the upgrade phase selection UI.
// The other functions are for file reading and writing. (for custom maps see custom config instructions word doc)
// These functions have specific exception handling to help debug errors when thrown.
#pragma once
#ifndef input_validation_h
#define input_validation_h
#include<string>
#include<vector>
#include<iostream>
#include<algorithm>
#include<string>
#include<fstream>
#include"units_and_upgrades.h" // for config_save_game
#include"board_tile.h"        //  for config_save_game
int int_list_input(const int start_int, const int last_int);
std::string two_char_input(std::string A, std::string B);
void rules_reader(std::string filename);
void check_files_valid(std::vector<std::string> file_list);
std::vector<std::vector<std::string>> config_reader( std::vector<std::shared_ptr<unit>>& units);
void config_save_game(std::vector<std::shared_ptr<unit>>& units, 
	std::vector<std::vector<std::unique_ptr<board_tile>>>& map,	std::vector<std::string> config_initial);
#endif