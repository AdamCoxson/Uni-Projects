// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// units_and_upgrades.h - 135 lines as of 10/05/2020, units_and_upgrades.cpp has 167 lines
// This contains classes for units and upgrades. Also contains a struct for the upgrade list.
// Upgrade abstract base class -> Derived: blank, attack, defence, siege, movement
// Unit abstract base class -> Derived: Army, Scout
// Units are objects which can be represented and moved around the board using functions within
// the board class. They are also able to initiate battles with other 'enemy' units and castles.
// The units are stored in the main in a vector of base class shared pointers.
#pragma once
#ifndef units_and_upgrades_h
#define units_and_upgrades_h
#include<string>
#include<iostream>
#include<vector>
class upgrade
{ // Abstract base class for upgrades
protected:
	std::string upgrade_type{ "" };
	int cost{ 0 };
public:
	upgrade() = default;
	~upgrade() {};
	int get_cost() { return cost; };
	int get_minimum_cost() { return 4; };
	std::string get_type() { return upgrade_type; };
	virtual void print_info(const int current_gold) = 0;
};
class blank : public upgrade
{
public:
	blank();
	~blank() {};
	void print_info(const int current_gold) {};
};
class siege_tactics : public upgrade
{
public:
	siege_tactics();
	~siege_tactics() {};
	void print_info(const int current_gold);
};
class defense : public upgrade
{
public:
	defense();
	~defense() {};
	void print_info(const int current_gold);
};
class attack : public upgrade
{
public:
	attack();
	~attack() {};
	void print_info(const int current_gold);
};
class movement : public upgrade
{
public:
	movement();
	~movement() {};
	void print_info(const int current_gold);
};
struct upgrade_list 
// This struct pushes back the 4 different unit upgrades to a vector upon construction.
// As such, one instance is created in the main without the need to push back to a vector in main.
{
	std::vector<std::shared_ptr<upgrade>> list;
	upgrade_list();
};

class unit
{ // Abstract base class, derives to army and scout
	friend std::ostream& operator<<(std::ostream& os, const std::shared_ptr<unit> unit);
protected:
	int x{};
	int y{};
	int moves{};
	int strength{};
	std::string unit_type{""};
	std::string team{ "" };
	std::shared_ptr<upgrade> upgrade_slot;
	static int blue_count; // Counters are tracked for the game win conditions 
	static int red_count;
	static int blue_army_count; // Tracked for max no. of armies allowed on board 
	static int red_army_count;
public:
	unit() = default;
	unit(const std::string team_in,const int strength_in,const int x_in,const int y_in,const std::string upgrade_in);
	virtual ~unit();
	const std::string get_type() const { return unit_type; }
	const std::string get_team() const { return team; }
	const std::string get_upgrade_type() const { return upgrade_slot->get_type(); }
	const int get_strength() const { return strength; } 
	const int getX() const { return x; }
	const int getY() const { return y; }
	const int get_moves() const { return moves; }
	const int unit_count(const std::string team) const; // returns unit counters
	const int army_count(const std::string team) const;
	void setXY(const int x_input, const int y_input);
	void upgrade(std::shared_ptr<upgrade> upgrade_in) { upgrade_slot = upgrade_in; }
	virtual void set_strength(const int new_strength) = 0; 
	virtual void add_one_strength() = 0;
	virtual void reduce_unit_count() = 0;
	virtual void print_unit_info()const = 0;
};
std::ostream& operator<<(std::ostream& os, const std::shared_ptr<unit> unit);
class army : public unit
{ // A unit which can be deployed to the board, upgraded and strength increased.
public:
	army() = default;
	army(const std::string team_in, const int strength_in, const int x_in, const int y_in, const std::string upgrade_in);
	~army() {};
	void set_strength(const int new_strength){ strength = new_strength; }
	void reduce_unit_count();
	void add_one_strength() {if (strength < 9) {strength++;}}; // armies limited to strength of 9
	void print_unit_info()const;

};
class scout : public unit
{ // A unit which can be upgraded but not deployed to the board, or strength increased.
public:
	scout() = default;
	scout(const std::string team_in, const int x_in, const int y_in, const std::string upgrade_in);
	~scout() {};
	void set_strength(const int new_strength) { strength = new_strength; }
	void reduce_unit_count();
	void add_one_strength() {} // scouts are limited to a strength of 1
	void print_unit_info() const;

};
#endif