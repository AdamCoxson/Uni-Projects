// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// battle.cpp - see battle.h description. 244 lines as of 10/05/2020

#include"battle.h"
dice::dice(const int faces_in, const int Num_dice_in) :faces{ faces_in }, Num_of_dice{ Num_dice_in }{}
std::vector<int> dice::roll_dice()
{
	for (int i{}; i < Num_of_dice; i++) { scores.push_back(rand() % faces + 1); }
	return scores;
};
std::vector<int> dice::sort_scores() const
{
	std::vector<int> sorted(scores);
	std::sort(sorted.begin(), sorted.end(), [](int a, int b){return a > b;});
	return sorted;
}
int dice::get_first_score() const
{
	int first_score = scores[0]; // when only 1 score is needed
	return first_score;
}
void dice::print_scores() const
{
	std::for_each(scores.begin(), scores.end(), [](int score) {std::cout << score << "\n"; });
}
void dice::reset_scores()
{
	for (int i{}; i < Num_of_dice; i++) { scores.pop_back(); }
};
void dice::reset_dice_params(const int faces_in, const int Num_of_dice_in)
{ // user can reset current dice parameters rather than start a new instance
	faces = faces_in;
	Num_of_dice = Num_of_dice_in;
};
void dice::reset_all(const int faces_in, const int Num_of_dice_in) 
{
	dice::reset_scores();
	dice::reset_dice_params(faces_in, Num_of_dice_in);
};
std::string retreat(int& retreater_strength) 
// Program takes in retreater strength by reference, unit removal/movement is dealt with in board::unit_move()
// Called when a player decides to retreat in the battle_function. Rolls a 9 sided dice for the retreater.
// If roll is 5 or more, unit retreats to nearest empty castle, otherwise unit is eliminated.
{
	dice retreat_dice(9, 1);
	retreat_dice.roll_dice();
	std::string retreat_outcome;
	std::cout << "Retreating, rolling a 9-sided die. Need a score of 5 or more to retreat ...\n";
	if (retreat_dice.get_first_score() > 4) {
		std::cout << "\n Rolled a " << retreat_dice.get_first_score() << ", greater than 4, successful retreat.\n";
		retreat_outcome = "retreat";
	} else {
		std::cout<<"\n Rolled a "<<retreat_dice.get_first_score() << ", less than 5, unit routed and lost.\n";
		retreat_outcome = "rout";
		retreater_strength = 0;
	}
	return retreat_outcome;
}

std::string unit_battle(std::shared_ptr<unit> attacker, std::shared_ptr<unit> defender, std::pair<bool,bool> empty_castle)
// This function takes in shared pointers to the attacking and defending units, as well as empty castle bool pair, if true, 
// there is an empty castle availbe for retreat. This function uses the dice class and a 'Risk' style dice roll to decide 
// unit battle outcomes. First, the units strengths are checked and the no. of dice to roll set to the minimum strength,
// e.g. attacker str = 5, defender = 3 means 3 dice will be rolled. The dice scores are sorted and matched highest to lowest.
// If the attackers score is lower than defenders, -1 strength and vice versa. If one of the sides does not entirely lose in 
// the first dice roll, multpile rounds can take place. This function also accounts for the attack and defense units upgrades.
// The output is one string of many different outcomes which board::unit_move() can then use to update the board map.
// Similarly to board::unit_move(), this function requires a complex system of nested if statements to check all outcomes.
{
	int attacker_strength{ attacker->get_strength() };
	int defender_strength{ defender->get_strength() };
	int attack_modifier{};
	int defense_modifier{};
	std::string continue_battle{};
	std::string battle_outcome{"ongoing"};
	if (attacker->get_upgrade_type() == "[a] Veteran Leaders") { attack_modifier = 2; }
	if (defender->get_upgrade_type() == "[d] Shields and Armour") { defense_modifier = 2; }
	int dice_number{ std::min(attacker_strength, defender_strength) };
	dice attack_dice(8 + attack_modifier, dice_number); // For each turn, match dice numbers to lowest strength
	dice defense_dice(8 + defense_modifier, dice_number); // I.e. 'Risk' style dice rolling but with no max of 3 dice
	std::cout << " " << attacker->get_team() << " is attacking, " << defender->get_team() << " is defending.\n";
	std::cout << " Initial strength: " << attacker->get_team() << " = " << attacker_strength << ", "
		      << defender->get_team() << " = " << defender_strength << "\n";
	std::cout << "\n The formations are deployed Commander.\n Commence the battle when ready (press enter).";
	std::getline(std::cin, continue_battle);
	while (battle_outcome == "ongoing") { // battle round loop
		attack_dice.roll_dice();
		defense_dice.roll_dice();
		std::vector<int>sorted_attack(attack_dice.sort_scores());
		std::vector<int>sorted_defense(defense_dice.sort_scores());
		std::cout << "\n Rolling and sorting dice (" << attacker->get_team() << " die, " << defender->get_team() << " die)\n";
		for (size_t i{}; i < sorted_attack.size(); i++) {
			std::cout << " " << attacker->get_team() << " rolled " << sorted_attack[i] << ", " << defender->get_team() <<
				" rolled " << sorted_defense[i];
			if (sorted_attack[i] > sorted_defense[i]) { // If attacker die is higher, defender - 1 strength
				std::cout << ". " << attacker->get_team() << " unit win.\n";
				defender_strength--;
			} else if (sorted_attack[i] < sorted_defense[i]) {
				std::cout << ". " << defender->get_team() << " unit win.\n";
				attacker_strength--;
			} else {
				attacker_strength--;
				defender_strength--;
				std::cout << ". Draw, both teams lose 1.\n";
			}
		}
		std::cout << " New strength: " << attacker->get_team() << " = " << attacker_strength << ", "
			<< defender->get_team() << " = " << defender_strength << "\n\n";
		if (defender_strength == 0 && attacker_strength == 0) {
			std::cout << " It was a brutal stalemate, both armies lie shattered on the battlefield.\n\n";
			battle_outcome = "stalemate";
			attacker->reduce_unit_count();
			defender->reduce_unit_count();
		}else if (attacker_strength == 0) {
			std::cout << " " << defender->get_team() << ", the defender, has won.\n";
			battle_outcome = "defender win";
			attacker->reduce_unit_count();
		}else if (defender_strength == 0) {
			std::cout << " " << attacker->get_team() << ", the attacker, has won.\n";
			battle_outcome = "attacker win";
			defender->reduce_unit_count();
		} else {  // If no outcome yet, give users choice to retreat.
			if (empty_castle.first == true) {
				std::cout << " " << attacker->get_team() << ", do you want to [a] continue the attack or [r] retreat?\n [a / r] : ";
				continue_battle = two_char_input("a", "r");
			} else {
				std::cout << " No empty castles to retreat to, " << attacker->get_team() << " must press the attack.\n";
				continue_battle = "a";
			}
			if (continue_battle == "a") {
				if (empty_castle.second == true) {
					std::cout << " " << attacker->get_team() << " intends to press the attack.\n";
					std::cout << " " << defender->get_team() << ", do you want to [h] hold fast or [r] retreat?\n [h / r] : ";
					continue_battle = two_char_input("h", "r");
				} else {
					std::cout << " No empty castles to retreat to, " << defender->get_team() << " must hold fast.\n";
					continue_battle = "h";
				}
				if (continue_battle == "h") {
					int dice_number = std::min(attacker_strength, defender_strength);
					attack_dice.reset_all(6 + attack_modifier, dice_number);
					defense_dice.reset_all(6 + defense_modifier, dice_number);
				} else  {
					std::cout << " " << defender->get_team() << " sounds the retreat!";
					std::string retreat_outcome = retreat(defender_strength);
					if (retreat_outcome == "retreat") {
						battle_outcome =  "defender retreat";
					} else if (retreat_outcome == "rout") {
						battle_outcome = "attacker win";
						defender->reduce_unit_count();
					}
				} 				
			} else  {
				std::cout << " " << attacker->get_team() << " sounds the retreat!";
				std::string retreat_outcome{ retreat(attacker_strength) };
				if (retreat_outcome == "retreat") {
					battle_outcome = "attacker retreat";
				} else if (retreat_outcome == "rout") {
					battle_outcome = "defender win";
					attacker->reduce_unit_count();
				}
			}
		}
	}
	attacker->set_strength(attacker_strength); // If strength 0, defeated unit removal is in main.cpp
	defender->set_strength(defender_strength);
	std::cout << "\n Press enter to exit the battle.\n";
	std::getline(std::cin, continue_battle);
	return battle_outcome;
};

std::string castle_siege(std::shared_ptr<unit> attacker, int& castle_strength) 
// This function takes in the attacking unit pointer and the strength of the castle by reference.
// First, the user is asked if they want to siege or skip and remain on the tile without capturing
// the castle. Otherwise, a 6-sided dice rolling system is used, one roll for attacker, one roll
// for castle defenders and resolved. Draws result in nothing. After each roll the player can
// continue to siege or stop sieging. This accounts for unit siege upgrade by letting the attacking
// roll a 8 sided dice, against defender 6-sided. Outputs a string outcome for use in board::move_unit().
{
	std::string continue_battle{};
	std::string battle_outcome{ "ongoing" };
	int attacker_strength{ attacker->get_strength() };
	int siege_modifier{};

	if (castle_strength == 0) { return "castle captured"; }
	else {
		std::cout << "\n " << attacker->get_team() << " attacker strength: " <<	attacker->get_strength() <<
			 ". Fortification strength: " << castle_strength << ".\n Would you like to siege the castle? (y/n): ";
		continue_battle = two_char_input("y", "n");
		if (continue_battle == "n") {return "siege halt";}
	}
	if (attacker->get_upgrade_type() == "[s] Siege Tactics") { siege_modifier = 2; } // account for unit upgrade
	dice attack_dice(6 + siege_modifier, 1); // 1 die roll per side.
	dice castle_dice(6, 1);
	std::cout << " " << attacker->get_team() << " is sieging an enemy castle!\n";
	std::cout << " Commence the siege when ready (press enter).";
	std::getline(std::cin, continue_battle);
	std::cout << "\n Rolling dice";
	while (battle_outcome == "ongoing"){
		attack_dice.roll_dice();
		castle_dice.roll_dice();
		std::cout << "\n " << attacker->get_team() << " attacker rolled a " << attack_dice.get_first_score() <<
			", defending castle rolled a " << castle_dice.get_first_score();
		if (attack_dice.get_first_score() > castle_dice.get_first_score()) {
			std::cout << ". " << attacker->get_team() << " attackers won the round.\n";
			castle_strength--;
		} else if (attack_dice.get_first_score() < castle_dice.get_first_score()) {
			std::cout << ". Castle defenders won the round.\n";
			attacker_strength--;
		} else {
			std::cout << ". Draw, no change.\n";
		}
		std::cout << " New attacker strength = " << attacker_strength  
			      << ". New castle strength = " << castle_strength << ".\n";
		if (attacker_strength == 0) { // End condition checks
			std::cout << "\n The castle defenders, have won!\n";
			battle_outcome = "castle defender win";
			attacker->reduce_unit_count();
			
		} else if (castle_strength == 0) {
			std::cout << "\n " << attacker->get_team() << ", the attacker, has won the siege.\n";
			battle_outcome = "castle captured";
		} else {
			std::cout << " " << attacker->get_team() << ", do you want to [y] continue the siege or [n] quit?" <<
				" (no penalty for quitting the siege)\n [y / n]: ";
			continue_battle = two_char_input("y", "n");
			if (continue_battle == "y") {
				attack_dice.reset_scores();
				castle_dice.reset_scores();
			} else {
				std::cout << "\n " << attacker->get_team() << " halts the siege \n";
				battle_outcome = "siege halt";
			}
		}
	}
	attacker->set_strength(attacker_strength); 
	std::cout << " Exit the siege result when ready (press enter).";
	std::getline(std::cin, continue_battle);
	return battle_outcome;
}