// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// Board.cpp - see board.h description. 512 lines as of 10/05/2020
#include"board.h"
int board::blue_castles{}; // Static variables used as count trackers
int board::red_castles{};
int board::blue_gold_tiles{};
int board::red_gold_tiles{};
int board::blue_gold{};
int board::red_gold{};
board::board(std::vector<std::shared_ptr<unit>> unit_list, std::vector<std::vector<std::string>> config):
	rows{ std::stoi(config[0][0]) }, cols{ std::stoi(config[0][1]) }
{
	std::cout << " Setting up board" << std::endl;
	blue_castles = 0;
	red_castles = 0;
	map.reserve(rows); // reserve memory to speed up program
	try {
		blue_gold = std::stoi(config[0][2]); // team starting gold
		red_gold = std::stoi(config[0][3]);
		std::vector<std::string>temp_tile{ "","","" };
		for (int k{}; k < rows; k++) { 
			map.emplace_back();
			map[k].reserve(cols);
		}
		for ( int i{}; i < rows; i++) { // Constructing the map variable of board_tiles
			for ( int j{}; j < cols; j++) {
				for (unsigned int k{ 1 }; k < config.size(); k++) {
					if (std::stoi(config[k][2]) == j && std::stoi(config[k][3]) == i) {
						temp_tile[0] = config[k][0]; // tile type
						temp_tile[1] = config[k][1]; // team
						temp_tile[2] = config[k][4]; // strength (for castles)
						break;
					}
				}
				if (temp_tile[0] == "Castle") {
					map[i].emplace_back(std::make_unique<castle>(temp_tile[1], stoi(temp_tile[2])));
					castle_list.emplace_back(std::make_pair(j, i)); // pair of x,y coords for castles
					if (temp_tile[1] == "Blue") { blue_castles++; }
					else if (temp_tile[1] == "Red") { red_castles++; }		 
				} else if (temp_tile[0] == "Obstacle") {
				    map[i].emplace_back(std::make_unique<obstacle>());
				} else if (temp_tile[0] == "Gold") {
					map[i].emplace_back(std::make_unique<gold_point>(temp_tile[1], 2)); 
				} else {
					map[i].emplace_back(std::make_unique<empty>());
				}
				temp_tile[0] = "";
			}
		}
		std::for_each(unit_list.begin(), unit_list.end(), [this](std::shared_ptr<unit> unit)
			{ map[unit->getY()][unit->getX()]->set_unit(unit); }); // setting units on the map
		for (int i{}; i < rows; i++) {
			for (int j{}; j < cols; j++) {
				map[i][j]->setXY(j,i);
			}
		}
	} catch (std::invalid_argument) { // try and catch incase of error in config file
		std::cerr << " Exception: Invalid argument. Check for errors in config file.\n";
		exit(1);
	} catch (std::out_of_range) {
		std::cerr << " Exception: Vector out of range. Check for errors in config file.\n";
		exit(1);
	} catch (std::bad_alloc) {
		std::cerr << " Exception: Out of memory. Check for errors in config file.\n";
		exit(1);
	} catch (...) {
		std::cerr << "Exception: Some unknown exception occured. Check for errors in config file.\n";
		exit(1);
	}
}
bool board::check_for_empty_castle(const std::string team) const
{
	for (auto current_castle : castle_list) {
		if (map[current_castle.second][current_castle.first]->get_team() == team
			&& map[current_castle.second][current_castle.first]->check_for_unit() == false) {
			return true;
		}
	}
	return false;
};
std::pair<int, int> board::find_closest_castle(const std::string team, const int x, const int y) const {
	int closest_x{ 10000 }; // Large initial values to activate if statement
	int closest_y{ 10000 };
	int closest_tot{ closest_y + closest_x };
	int difference{};
	for (auto it : castle_list) {
		if (map[it.second][it.first]->get_team() == team && map[it.second][it.first]->check_for_unit() == false) {
			difference = abs(it.first - x) + abs(it.second - y);
			if (difference < closest_tot) {
				closest_x = it.first;
				closest_y = it.second;
				closest_tot = closest_x + closest_y;
			}
		}
	}
	if (difference == 0 || closest_tot == 20000) { // no empty, friendly castles found
		closest_x = NULL;
		closest_y = NULL;
	}
	return std::make_pair(closest_x, closest_y); // return x,y of closest castle
}
int board::get_gold_tiles(const std::string team) const
{
	if (team == "Red") { return red_gold_tiles; }
	else if (team == "Blue") { return blue_gold_tiles; }
	else { return -1; }
}
int board::get_gold(const std::string team) const 
{
	if (team == "Red") { return red_gold; }
	else if (team == "Blue") { return blue_gold; }
	else { return -1; }
}
int board::get_castles(const std::string team) const
{
	if (team == "Red") { return red_castles; } // controlled castle counts
	else if (team == "Blue") { return blue_castles; }
	else { return -1; }
}
void board::edit_gold_tiles(const std::string team, const std::string increment)
// Tracks number of controlled gold tiles so the program can correctly allocate gold 
// each turn in board::total_up_gold.
{
	if (team == "Red" && increment == "add") { red_gold_tiles++; }
	else if (team == "Red" && increment == "minus") { red_gold_tiles--; }
	else if (team == "Blue" && increment == "add") { blue_gold_tiles++; }
	else if (team == "Blue" && increment == "minus") { blue_gold_tiles--; }
	else {}
}
void board::spend_gold(const std::string team, const int gold_cost)
{
	if (team == "Red") { red_gold = red_gold - gold_cost; }
	else if (team == "Blue") { blue_gold = blue_gold - gold_cost; }
}
void board::total_up_gold(const std::string team) 
{   // Start of upgrade phase, this is used to add to palyers current gold
	if (team == "Blue") {
		blue_gold = blue_gold + 2 * blue_gold_tiles + blue_castles;	
	} else if (team == "Red") {
		red_gold = red_gold + 2 * red_gold_tiles + red_castles;
	}
}
void board::edit_castle_count(const std::string team, const std::string increment)
{   // called whenever a castle is captured
	if (team == "Red" && increment == "add") { red_castles++; } 
	else if (team == "Red" && increment == "minus") { red_castles--; }
	else if (team == "Blue" && increment == "add") { blue_castles++; }
	else { blue_castles--; }
}
void board::upgrade_castle(const std::string team) 
// This function takes in the current team chooisng to upgrade their castles. This function deals with the UI
// to help the player choose which castle to upgrade, showing the cost and current fortifications. This 
// function also has some basic validation of the castle choice.
{
	int choice{};
	int idx{};
	int j{};
	int gold{ get_gold(team) };
	int cost{};
	int strength{};
	std::vector<int> castle_idx(castle_list.size(), 0);
	std::cout << "\n Available gold: " << gold << "\n";
	std::cout << " [0] Cancel - back to previous selection.\n";
	for (size_t i{}; i < castle_list.size(); i++) {
		if (map[castle_list[i].second][castle_list[i].first]->get_team() == team){ // List teams castles
			strength = map[castle_list[i].second][castle_list[i].first]->get_strength();
			std::cout << " [" << j + 1 << "]" << " Castle at "	<< ((char)(castle_list[i].second + 65)) 
				<< " " << castle_list[i].first << ". Fortification strength: "<< strength; 
			if (strength == 4) {
				std::cout << ". Maxiumum fortification reached.\n"; // 4 is the max strength a castle can be
		    } else if (strength == 3) { 
				std::cout << ". New strength: 4. Cost: 3.\n";
			} else {
				std::cout << ". New strength: " << strength+2 << ". Cost: 6.\n";
			}
			castle_idx[j] = i;
			j++;
		}
	}
	std::cout << " Choose an option (input number identifier): ";
	while (true) {
		choice = int_list_input(0, j); 
		if (choice == 0) {break;}
		idx = castle_idx[choice - 1];
		strength = map[castle_list[idx].second][castle_list[idx].first]->get_strength();
		if (strength == 3) { cost = 3; }
		else  { cost = 6; }
		if (strength > 3) {
			std::cout << " Cannot upgrade castle further! Choose another option or cancel: ";
		} else if (cost > gold) {
			std::cout << " You don't have enough gold! Choose another option or cancel: ";
		} else if (strength == 3) {
			strength = strength + 1;
			map[castle_list[idx].second][castle_list[idx].first]->set_strength(strength);
			spend_gold(team, cost);
			break;
		} else { 
			strength = strength + 2;
			map[castle_list[idx].second][castle_list[idx].first]->set_strength(strength);
			spend_gold(team, cost);
			break;
		}
	}
}
void board::deploy_army(const std::string team, std::shared_ptr<unit> unit)
// This function takes in the current team and a pointer to the new unit being deployed. Unit construction done
// in the main. This function finds and diplays the empty friendly castles to the user. The user can then choose
// which castle to deploy at. If only one empty castle availabe then that is automaticaly chosen.
{
	int choice;
	std::vector<std::pair<int, int>> valid_castles; // pair of x,y coords for empty castles
	std::for_each(castle_list.begin(), castle_list.end(), [&team, &valid_castles, this](std::pair<int, int> castle)
		{   // This lambda finds the valid, empty castles 
			if (map[castle.second][castle.first]->get_team() == team
				&& map[castle.second][castle.first]->check_for_unit() == false) {
				valid_castles.emplace_back(std::make_pair(castle.first, castle.second));
			}
		});
	if (valid_castles.size() == 1) {
		choice = 1;
		std::cout << " Deploying in only empty castle available at " << ((char)(valid_castles[0].second + 65))
			<< " " << valid_castles[0].first << ".\n";
	}
	else {
		for (size_t i{}; i < valid_castles.size(); i++) {
			std::cout << " [" << i + 1 << "]" << " Castle at " << ((char)(valid_castles[i].second + 65))
				<< " " << valid_castles[i].first << ".\n";
		}
		std::cout << " Choose an option (input number identifier): ";
		choice = int_list_input(1, valid_castles.size());
	}
	map[valid_castles[choice - 1].second][valid_castles[choice - 1].first]->set_unit(unit);
	unit->setXY(valid_castles[choice - 1].first, valid_castles[choice - 1].second); // setting unit pointers
}
void board::print_board(const std::shared_ptr<unit> current_unit) const 
{ // This prints out the board map, left to right from top row to bottom. Puts a * tile of any moving units
	bool moving_unit{ false };                                    // |____|
	std::cout << "\n     ";                                       // | BC | // top tile row, Blue castle,
	for (int x_vals{}; x_vals < cols; x_vals++) {                 // |BA5 | // middle, Blue army strength 5
		if (x_vals < 10) { std::cout << "  " << x_vals << "  "; } // |____| // Blank bottom section
		else { std::cout << "  " << x_vals << " "; }
	}
	std::cout << "\n     ";  // top x coordinates and top straight line 
	for (int k_top{}; k_top < cols; k_top++)std::cout << " ____";
	std::cout << "\n";
	for (int i{}; i < rows; i++) {
		std::cout << "     ";
		for (int j{}; j < cols; j++) {  // print the tile sections for each column in row
			if (current_unit == map[i][j]->get_unit() && current_unit != nullptr) { moving_unit = true; }
			map[i][j]->print_tile(moving_unit);
			moving_unit = false;
		}
		std::cout << "|\n" << "   " << ((char)(i + 65)) << " "; // left Y axis letters
		for (int j{}; j < cols; j++) {
			if (map[i][j]->get_type() == "Obstacle") {  // print unit sections for each column in row
				map[i][j]->print_tile(false);
			} else if (map[i][j]->check_for_unit() == true) {
				std::cout << "|" << map[i][j]->get_unit();
			} else {
				std::cout << "|    ";
			}
		}
		std::cout << "| " << ((char)(i + 65)) << "\n     "; // right Y axis letters
		for (int k_end{}; k_end < cols; k_end++)std::cout << "|____"; // blank bottom section
		std::cout << "|" << std::endl;
	}
	std::cout << "\n     ";
	for (int x_vals{}; x_vals < cols; x_vals++) {
		if (x_vals < 10) { std::cout << "  " << x_vals << "  "; } // Bottom row of x coordinates
		else { std::cout << "  " << x_vals << " "; }
	}
	std::cout << "\n     ";
}
void board::battle_conditions(std::string battle_outcome, std::shared_ptr<unit>& unit, int& x, int& y)
// This function is simply to help break up the outcome validation in the unit move function
// Specifically, when a battle or seige has finished, there are a number of outcomes and secondary checks.
// E.g. attacker defeated a defender on the defenders castle, give attacker choice to immediately siege.
// This accounts for unit battle wins, losses, draws, retreats and castle sieges.
{
	int old_x = unit->getX();
	int old_y = unit->getY();
	std::string team = unit->get_team();
	std::string siege_outcome{ "" };
	if (battle_outcome == "attacker retreat") {
		std::pair<int, int> closest_castle{ find_closest_castle(team, x, y) };
		if (closest_castle.first != NULL || closest_castle.second != NULL) { // find nearest, unoccupied castle
			unit->setXY(closest_castle.first, closest_castle.second);
			map[closest_castle.second][closest_castle.first]->set_unit(unit);
		}
		else {
			std::cout << "\n No empty or valid castles to retreat to, " << team << " unit lost.\n";
			unit->set_strength(0);
		}
		map[old_y][old_x]->set_unit(nullptr);
		x = old_x;
		y = old_y;
	}
	else if (battle_outcome == "defender retreat") {
		std::pair<int, int>closest_castle{ find_closest_castle(map[y][x]->get_unit()->get_team(), x, y) };
		if (closest_castle.first != NULL || closest_castle.second != NULL) {
			map[y][x]->get_unit()->setXY(closest_castle.first, closest_castle.second);
			map[closest_castle.second][closest_castle.first]->set_unit(map[y][x]->get_unit());
		}
		else {
			std::cout << "\n No empty or valid castles to retreat to, "
				<< map[y][x]->get_unit()->get_team() << " unit lost\n";
			map[y][x]->get_unit()->reduce_unit_count();
			map[y][x]->get_unit()->set_strength(0);
		}
		unit->setXY(x,y);
		map[y][x]->set_unit(nullptr);
		map[y][x]->set_unit(unit);
		map[old_y][old_x]->set_unit(nullptr);
		// If a castle is present on the tile after attacking and beating enemy
		if (map[y][x]->get_type() == "Castle" && map[y][x]->get_team() != team) {
			int castle_strength{ map[y][x]->get_strength() };
			siege_outcome = castle_siege(unit, castle_strength);
			map[y][x]->set_strength(castle_strength);
			if (siege_outcome == "castle captured") {
				edit_castle_count(team, "add");
				edit_castle_count(map[y][x]->get_team(), "minus");
				map[y][x]->set_team(team);
			}
			else if (siege_outcome == "castle defender win") {
				map[y][x]->set_unit(nullptr); // Remove defeated sieging unit
			}
			else {} // Siege halts
		}
		else if (map[y][x]->get_type() == "Gold" && map[y][x]->get_team() != team) {
			std::cout << " " << team << " captured " << map[y][x]->get_team() << "'s gold resource point.\n";
			edit_gold_tiles(map[y][x]->get_team(), "minus"); // Enemy gold point captured
			edit_gold_tiles(team, "add");
			map[y][x]->set_team(team);
		}
		else {}
		x = old_x;
		y = old_y;
	}
	else if (battle_outcome == "attacker win") {
		map[y][x]->set_unit(nullptr); // Remove tile pointer to defeated defender
		if (map[y][x]->get_type() == "Castle" && map[y][x]->get_team() != team) {
			int castle_strength{ map[y][x]->get_strength() };
			siege_outcome = castle_siege(unit, castle_strength);
			map[y][x]->set_strength(castle_strength);
			if (siege_outcome == "castle captured") {
				edit_castle_count(team, "add");
				edit_castle_count(map[y][x]->get_team(), "minus");
				map[y][x]->set_team(team);
			} else if (siege_outcome == "castle defender win") {
				map[old_y][old_x]->set_unit(nullptr); // Remove defeated sieging unit
				x = old_x;
				y = old_y;
			} else {/* Siege halted */} 
		}
		else if (map[y][x]->get_type() == "Gold" && map[y][x]->get_team() != team) {
			std::cout << " " << team << " captured " << map[y][x]->get_team() << "'s gold resource point.\n";
			edit_gold_tiles(map[y][x]->get_team(), "minus"); // Enemy gold point captured
			edit_gold_tiles(team, "add");
			map[y][x]->set_team(team);
		}
	}
	else if (battle_outcome == "defender win") {
		map[old_y][old_x]->set_unit(nullptr); // Remove tile pointer to defeated attacker
		x = old_x; y = old_y;
	}
	else if (battle_outcome == "stalemate") {
		map[old_y][old_x]->set_unit(nullptr);
		map[y][x]->set_unit(nullptr);
		x = old_x; y = old_y;
	}
}
void board::move_unit(std::shared_ptr<unit> unit) 
// This is the most complex function in the program, input is the unit currently being moved.
// This program gets the location data from the unit and move input from the user. Using a series
// nested if and else statements, the program checks many possible conditions, such as landed on 
// and out of bounds location, landing on an enemy unit or castle to initiate the battle functions.
// Finally, valid move inputs are resolved, the move function checks the outcome of any battles.
// board tile to Unit pointers are updated accordingly. This also accounts for unit movement upgrade.
{
	int old_x{ unit->getX() };
	int old_y {unit->getY()};
	int x{ unit->getX() };
	int y{ unit->getY() };
	std::string team{ unit->get_team() };
	std::string battle_outcome{ "" };
	std::string siege_outcome{ "" };
	unsigned int moves{ 0 };
	std::pair<bool, bool> empty_castles(std::make_pair(false, false));

	print_board(unit); // print board with '*' identifying the unit tile
	if (unit->get_upgrade_type()[1] == 'm') { moves = unit->get_moves() + 1; }
	else { moves = unit->get_moves(); }
	std::cout << "\n Moving unit"; unit->print_unit_info();
	bool valid_move{ false };
	while (valid_move == false) {
		std::string move_input;
		bool valid_input{ false };
		while (valid_input == false) {
			std::cout << " Input up to ("<<moves<<") moves: ";
			move_input.clear();
			std::getline(std::cin, move_input);
			if (move_input.length() <= moves && move_input.length() > 0) {
				for (size_t i{}; i < move_input.length(); i++) {
					char str = tolower(move_input[i]);
					if (str == 'w' || str == 'a' || str == 's' || str == 'd') {
						if (i == move_input.length() - 1) { valid_input = true; }
					} else {
						std::cout << " Invalid input.";
						break;
					}
				}
			} else if (move_input.length() == 0) { 
				valid_input = true;
			}else { 
				std::cout << " Too many moves entered.";
			}
		}
		for (auto str : move_input) {
			if (tolower(str) == 'w') { y--; }
			else if (tolower(str) == 's') { y++; }
			else if (tolower(str) == 'a') { x--; }
			else if (tolower(str) == 'd' ) { x++; }
			if (x > cols - 1 || x < 0 || y > rows - 1 || y < 0) {
				break; // Checking each x,y, increment to ensure unit does not move through enemies/obstacles without trigger
			} else if (map[y][x]->get_type() == "Obstacle") { 
				break;                                        
			} else if (map[y][x]->check_for_unit() == true && map[y][x]->get_unit()->get_team() != team) {
				std::cout << "\n Contact has been made with the enemy." << std::endl;
				empty_castles.first = check_for_empty_castle(unit->get_team());
				empty_castles.second = check_for_empty_castle(map[y][x]->get_unit()->get_team());
				battle_outcome = unit_battle(unit, map[y][x]->get_unit(), empty_castles);
				break;
			}
		}
		if (battle_outcome != "") {
			battle_conditions(battle_outcome, unit, x, y); // Battle_conditions function defined line 283
			valid_move = true;
			break;
		} else if (x > cols - 1 || x < 0 || y > rows - 1 || y < 0) {
			std::cout << " Out of map boundary.";
		} else if (map[y][x]->get_type()=="Obstacle") { 
			std::cout << " Obstacle in the way.";
		} else if (map[y][x]->check_for_unit()==true && map[y][x]->get_unit()->get_team()==team && unit!=map[y][x]->get_unit()) {
			std::cout << " Another friendly unit is already there.";
		} else if (map[y][x]->get_team() != team && map[y][x]->get_type() == "Castle") {
			
			if (map[y][x]->get_team() == " "){ // neutral castle captured
				edit_castle_count(team, "add");
				map[y][x]->set_team(team);
			} else if (map[y][x]->get_team() != team) { // Enemy castle on target tile
				int castle_strength{ map[y][x]->get_strength() };
				siege_outcome = castle_siege(unit, castle_strength);
				map[y][x]->set_strength(castle_strength);
				if (siege_outcome == "castle captured") {
					edit_castle_count(team, "add");
					edit_castle_count(map[y][x]->get_team(), "minus");
					map[y][x]->set_team(team);
				} else if (siege_outcome == "castle defender win") {
					map[old_y][old_x]->set_unit(nullptr); // remove defeated sieging unit
					x = old_x;
					y = old_y;
				} else {} // siege halts
			}
			valid_move = true;
			break;
		} else if (map[y][x]->get_team() != team && map[y][x]->get_type() == "Gold") {
			if (map[y][x]->get_team() == " ") { // neutral gold point captured
				std::cout <<" " << team << " secured a gold resource point.\n";
			} else if (map[y][x]->get_team() != team) {
				edit_gold_tiles(map[y][x]->get_team(), "minus"); // enemy gold point captured
				std::cout <<" "<< team << " captured a "<< map[y][x]->get_team() << " gold resource point.\n";
			}
			edit_gold_tiles(team, "add");
			map[y][x]->set_team(team);
			valid_move = true;
			break;
		} else if (x == old_x && y == old_y) {
			std::cout << " Unit has not moved.";
			valid_move = true;
		} else {
			valid_move = true;
			break;
		}
		x = old_x; // If move invalid reset x and y to retry
		y = old_y;
	}
	if (x == old_x && y == old_y) {}
	else {
		unit->setXY(x,y); // Update unit and map pointer coordinates
		map[y][x]->set_unit(unit);
		map[old_y][old_x]->set_unit(nullptr);
	}
}
void board::swap_board(std::shared_ptr<unit> unit_to_swap, board& new_board, const int new_x, const int new_y)
// This function takes in a unit pointer and a different instance of the board class to the units current board,
// as well as the new x and y coordinates. The function can then reset board_tile unit pointers to 
// put the unit onto a new board, nearly equivalent to how the units moves around a board in move_unit().
// NOTE: Multiple board instances haven't been implemented yet. When they are, need to include:
// - Unit board tracking - to differentiate between what unit belongs to which board's map, could use variable or namespaces?
// - Input validation - if the unit's current board was passed into this function as the new board,
//   the tile would set itself to nullptr and the unit would not show up on any board! 
{
	int old_x{ unit_to_swap->getX() };
	int old_y{ unit_to_swap->getY() };
	unit_to_swap->setXY(new_x, new_y);
	new_board.map[new_y][new_x]->set_unit(unit_to_swap);
	map[old_x][old_y]->set_unit(nullptr);
}