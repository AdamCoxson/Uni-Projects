// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// units_and_upgrades.cpp - 167 lines as of 10/05/2020 see units_and_upgrades.h for description.
#include"units_and_upgrades.h"
blank::blank() : upgrade() 
{
	cost = 0;
	upgrade_type = "None";
}
siege_tactics::siege_tactics() : upgrade()
{
	cost = 6;
	upgrade_type = "[s] Siege Tactics";
}
void siege_tactics::print_info(const int current_gold)
{
	std::cout << "\n Upgrade: Siege tactics. Cost: " << cost << ".\n";
	std::cout << " Info: Siege tactics increase the chances of defeating fortifications during sieges.\n";
}
defense::defense() : upgrade()
{
	cost = 4;
	upgrade_type = "[d] Shields and Armour";
}
void defense::print_info(const int current_gold)
{
	std::cout << "\n Upgrade: Shields and Armour. Cost: " << cost << ".\n";
	std::cout << " Info: Shields and Armour improve the chances of winning when defending from an attack.\n";
}
attack::attack() : upgrade()
{
	cost = 4;
	upgrade_type = "[a] Veteran Leaders";
}
void attack::print_info(const int current_gold)
{
	std::cout << "\n Upgrade: Veteran leaders. Cost: " << cost << ".\n";
	std::cout << " Info: Veteran leaders improve the chances of winning when attacking enemy units.\n";
}
movement::movement() : upgrade()
{
	cost = 4;
	upgrade_type = "[m] Mounted Army";
}
void movement::print_info(const int current_gold)
{
	std::cout << "\n Upgrade: Mounted army. Cost: " << cost << ".\n";
	std::cout << " Info: Mounting your army allows for quick traversal across the map.\n";
}
upgrade_list::upgrade_list() {
	list.emplace_back(std::make_shared<attack>());
	list.emplace_back(std::make_shared<defense>());
	list.emplace_back(std::make_shared<siege_tactics>());
	list.emplace_back(std::make_shared<movement>());
}
int unit::blue_count{}; // Static variables
int unit::red_count{};
int unit::blue_army_count{};
int unit::red_army_count{};
unit::unit(const std::string team_in, const int strength_in, const int x_in, const int y_in, const std::string upgrade_in) :
	team{ team_in }, strength{ strength_in }, x{ x_in }, y{ y_in }
{
	if (upgrade_in == "attack") {
		upgrade_slot = std::make_shared<attack>();
	} else if (upgrade_in == "defense") {
		upgrade_slot = std::make_shared<defense>();
	} else if (upgrade_in == "siege") {
		upgrade_slot = std::make_shared<siege_tactics>();
	} else if (upgrade_in == "move") {
		upgrade_slot = std::make_shared<movement>();
	} else {
		upgrade_slot = std::make_shared<blank>();
	}
	if (team == "Blue") { blue_count++; }
	else { red_count++; }
}
unit::~unit() {}
const int unit::unit_count(const std::string team) const
{
	if (team == "Blue") {
		return blue_count;
	} else if (team == "Red") {
		return red_count;
	} else {
		std::cout << " Team name input error, exiting program" << std::endl;
		exit(1);
	}
};
const int unit::army_count(const std::string team) const
{
	if (team == "Blue") {
		return blue_army_count;
	} else if (team == "Red") {
		return red_army_count;
	} else {
		std::cout << " Team name input error, exiting program" << std::endl;
		exit(1);
	}
};
void unit::setXY(const int x_input, const int y_input)
{
	x = x_input;
	y = y_input;
}
std::ostream& operator<<(std::ostream& os, const std::shared_ptr<unit> unit) 
{
	std::string upgrade_char{ " " };
	if (unit->get_upgrade_type() == "None") {}
	else { upgrade_char = unit->get_upgrade_type()[1]; }
	if (unit->get_type() == "Scout") {
		os << unit->get_team()[0] << "Sc" << upgrade_char;
	} else {
		os << unit->get_team()[0] << unit->get_type()[0]
			<< unit->get_strength() << upgrade_char;
	}
	return os;
};
army::army(const std::string team_in, const int strength_in, const int x_in, const int y_in, const std::string upgrade_in) :
	unit(team_in, strength_in, x_in, y_in, upgrade_in)
{
	if (team == "Blue") { blue_army_count++; } // static count trackers incremented on construction
	else { red_army_count++; }
	moves = 3;
	unit_type = "Army";
	team = team_in;
}
void army::print_unit_info() const
{
	std::cout << " " << team[0] << "A" << strength << " at " << ((char)(y + 65))
		<< " " << x << ". Upgrade: " << get_upgrade_type() << std::endl;
};
void army::reduce_unit_count() 
{ // static count trackers decremented when unit eliminated in board.cpp and battle.cpp
	if (team == "Blue") { 
		blue_count--;
		blue_army_count--;
	} else if (team == "Red") {
		red_count--;
		red_army_count--;
	} else {
		std::cout << "\n Some error occured in reduce_unit_count \n" << std::endl;
	}
}
scout::scout(const std::string team_in, const int x_in, const int y_in, const std::string upgrade_in) :
	unit(team_in, 1, x_in, y_in, upgrade_in)
{
	moves = 5;
	unit_type = "Scout";
	team = team_in;
}
void scout::print_unit_info() const
{
	std::cout << " " << team[0] << "Sc" << " at " << ((char)(y + 65))
		<< " " << x << ". Upgrade: " << get_upgrade_type() << std::endl;
};
void scout::reduce_unit_count() {
	if (team == "Blue") {
		blue_count--;
	} else if (team == "Red") {
		red_count--;
	} else {
		std::cout << "\n Some error occured in reduce_unit_count \n" << std::endl;
	}
}