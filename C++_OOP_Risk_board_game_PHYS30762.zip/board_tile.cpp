// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// board_tile.cpp - see board_tile.h for description. 63 lines as of 10/05/2020.
#include "board_tile.h"
void board_tile::setXY(const int x_input, const int y_input) 
{
	x = x_input;
	y = y_input; 
}
bool board_tile::check_for_unit() const 
{
	return (unit_slot != nullptr) ? true : false;
}
void empty::print_tile(const bool moving_unit) const 
{
	std::string output{ (moving_unit == true) ? "|*   " : "|    " };
	std::cout << output;
}
obstacle::obstacle():board_tile() 
{
	tile = "Obstacle";
}
void obstacle::print_tile(const bool moving_unit) const 
{
	std::cout << "|~~~~";
}
gold_point::gold_point(std::string team_in, int strength_in):board_tile(), strength{ strength_in } 
{
	team = team_in;
	tile = "Gold";
}
void gold_point::print_tile(const bool moving_unit) const 
{
	if (moving_unit == true) {
		std::cout << "|*" << team[0] << "G" << " ";
	} else{
		std::cout << "| " << team[0] << "G" << " ";
	}
}
castle::castle(std::string team_in, int strength_in) :board_tile(), strength{strength_in} 
{
	team = team_in;
	tile = "Castle";
}
castle::~castle() {}
int castle::get_strength() const 
{ 
	return strength; 
}
void castle::set_strength(const int new_strength) 
{ 
	strength = new_strength;
}
void castle::print_tile(const bool moving_unit) const {
	std::string strength_char{ " " };
	char moving_unit_char{' '};
	if (strength != 0) { strength_char = std::to_string(strength); } 
	if (moving_unit == true) { moving_unit_char = '*'; }
	std::cout << "|" << moving_unit_char << team[0] << "C" << strength_char;
}