// PHYS30762 CPP Object Oriented Programming - Niels Walet
// OOP project - A 'Risk' style board game
// Adam Coxson 3rd Year MPHYS University of Manchester
// Compiled on Windows 10 OS, Visual Studio 19 version 16.5.4
// ------------------------------------------------------------
// Board.h - 57 lines as of 10/05/2020, board.cpp has 512 lines
// This contains the single board class which is the main link between the individual board tiles
// and units. It has a number of functions necessary for moving and deploying units, as well as
// updating Static int counters for the win conditions.
// Note the public 'map' variable on line 37 - this is the main link between units and tiles.
#pragma once
#ifndef board_h
#define board_h
#include<string>
#include<vector>
#include<iostream>
#include<memory>
#include<list>
#include<chrono> // Timing functions for benchmarking
#include"battle.h"
#include"units_and_upgrades.h"
#include"board_tile.h"
#include"input_validation.h" // only uses int_list_input() and two_char_input()
class board
{
protected:
	int rows{};
	int cols{};
	static int red_castles;
	static int blue_castles;
	static int red_gold_tiles;
	static int blue_gold_tiles;
	static int red_gold;
	static int blue_gold;
	std::vector<std::pair<int, int>> castle_list;
public:
	std::vector<std::vector<std::unique_ptr<board_tile>>> map;
	board() = default;
	board(std::vector<std::shared_ptr<unit>> unit_list, std::vector<std::vector<std::string>> config);
	~board() {}
	bool check_for_empty_castle(const std::string team) const;
	std::pair<int, int> find_closest_castle(const std::string team, const int x, const int y) const;
	int get_gold_tiles(const std::string team) const;
	int get_gold(const std::string team) const;
	int get_castles(const std::string team) const;
	void edit_gold_tiles(const std::string team, const std::string increment);
	void spend_gold(const std::string team, const int gold_cost);
	void total_up_gold(const std::string team);
	void edit_castle_count(const std::string team, const std::string increment);
	void upgrade_castle(const std::string team);
	void deploy_army(const std::string team, std::shared_ptr<unit> unit);
	void print_board(const std::shared_ptr<unit> current_unit) const;
	void battle_conditions(const std::string battle_outcome, std::shared_ptr<unit> &unit, int &x, int &y);
	void move_unit(std::shared_ptr<unit> unit);
	void swap_board(std::shared_ptr<unit> unit_to_swap, board& new_board, const int new_x, const int new_y);
};
#endif