README for Graphene pyEIT code development

Authors: Adam Coxson & Frederik Brookebarnes, MPhys Undergrad, The University of Manchester
Email: adamcoxson1@gmail.com
Project: Automated Electrical Impedance Tomography of Graphene, Sept 2020
Report: ---
Google drive for entire project: ---
Supervisor: Artem Mischenko
	  Condensed Matter group, School of Physics and Astronomy, Uni of Manchester.
Email: artem.mishchenko@gmail.com

This was for our MPhys research project into EIT for Graphene samples. This code is based heavily on the vanilla
code for pyEIT. We have made a number of modifications to help us understand the code required for EIT and
so we could implement it ourselves. THIS MAY NOT BE A FINAL VERSION, IT IS CURRENTLY IN DEVELOPMENT.
